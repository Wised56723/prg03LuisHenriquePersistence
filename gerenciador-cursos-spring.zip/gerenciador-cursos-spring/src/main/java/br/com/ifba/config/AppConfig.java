/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.config;

/**
 *
 * @author luis2
 */


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.springframework.context.annotation.Bean; // Importe esta anotação
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "br.com.ifba")
public class AppConfig {

    @Bean // Esta anotação transforma o retorno do método em um Bean gerenciado pelo Spring.
    public EntityManager entityManager() {
        // Cria a fábrica de EntityManager a partir do persistence.xml
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("prg03persistencia");
        // Retorna o EntityManager que será injetado nos nossos DAOs
        return factory.createEntityManager();
    }
}