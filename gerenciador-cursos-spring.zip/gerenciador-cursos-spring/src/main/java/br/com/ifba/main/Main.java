/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.main;

/**
 *
 * @author luis2
 */


import br.com.ifba.config.AppConfig;
import br.com.ifba.curso.controller.CursoIController;
import br.com.ifba.curso.view.CursoTela;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        // 1. Inicializa o contexto do Spring com base na nossa classe de configuração.
        // O Spring escaneia os pacotes, encontra @Repository, @Service, @Controller
        // e gerencia todas as injeções de dependência com @Autowired.
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        System.out.println("Spring Context inicializado. Backend pronto!");

        // 2. Pede ao Spring para nos fornecer o Bean do Controller.
        // Não usamos 'new CursoController()'. Pedimos a instância gerenciada.
        CursoIController controller = context.getBean(CursoIController.class);

        // 3. Inicia a interface gráfica (View)
        // Usamos o EventQueue para garantir que a UI Swing rode na thread correta.
        java.awt.EventQueue.invokeLater(() -> {
            // Cria a tela, passando o controller que o Spring nos deu.
            CursoTela tela = new CursoTela(controller);
            tela.setVisible(true);
        });
    }
}