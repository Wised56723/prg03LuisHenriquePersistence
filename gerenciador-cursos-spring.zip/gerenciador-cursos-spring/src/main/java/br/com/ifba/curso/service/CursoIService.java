/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.service;

/**
 *
 * @author luis2
 */

import br.com.ifba.curso.entity.Curso;
import java.util.List;

public interface CursoIService {
    
    // Salva um novo curso no banco
    Curso saveCurso(Curso curso);
    
    // Atualiza um curso existente
    Curso updateCurso(Curso curso);
    
    // Deleta um curso
    void deleteCurso(Curso curso);
    
    // Retorna todos os cursos
    List<Curso> getAllCursos();
    
    // Busca um curso pelo ID
    Curso findCursoById(Long id);
    
    // Busca cursos pelo nome
    List<Curso> findByName(String nome);
}
