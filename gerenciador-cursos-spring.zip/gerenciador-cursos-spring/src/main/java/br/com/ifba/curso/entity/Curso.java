/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.entity;

/**
 *
 * @author luis2
 */

import br.com.ifba.infrastructure.entity.PersistenceEntity;
import jakarta.persistence.Entity;

@Entity // Marca a classe como uma entidade JPA (uma tabela no banco)
public class Curso extends PersistenceEntity {

    private String nome;
    private String codigo;
    private int cargaHoraria;
    private int vagas;
    private boolean ativo;

    // Crie os getters e setters para todos os campos...

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public int getCargaHoraria() { return cargaHoraria; }
    public void setCargaHoraria(int cargaHoraria) { this.cargaHoraria = cargaHoraria; }
    public int getVagas() { return vagas; }
    public void setVagas(int vagas) { this.vagas = vagas; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
}
