/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.view;

/**
 *
 * @author luis2
 */

import br.com.ifba.curso.controller.CursoIController;
import br.com.ifba.curso.entity.Curso;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

// Usando um JFrame simples para este exemplo.
// Você pode usar o construtor visual do NetBeans para gerar o código dos componentes.
public class CursoTela extends javax.swing.JFrame {

    // A tela agora RECEBE o controller, ela não o cria mais.
    private final CursoIController cursoController;
    private JTable tabelaCursos;
    private DefaultTableModel tabelaModelo;

    /**
     * Construtor que recebe o controller via Injeção de Dependência manual.
     */
    public CursoTela(CursoIController cursoController) {
        this.cursoController = cursoController;
        initComponents();
        carregarCursosNaTabela();
    }

    private void initComponents() {
        // Configurações básicas da janela
        setTitle("Gerenciamento de Cursos com Spring");
        setSize(800, 600);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Painel principal e botões (exemplo simplificado)
        javax.swing.JPanel painel = new javax.swing.JPanel();
        
        // Botão Adicionar
        javax.swing.JButton btnAdicionar = new javax.swing.JButton("Adicionar");
        btnAdicionar.addActionListener(evt -> adicionarCurso());
        
        // Botão Editar
        javax.swing.JButton btnEditar = new javax.swing.JButton("Editar");
        btnEditar.addActionListener(evt -> editarCurso());

        // Botão Remover
        javax.swing.JButton btnRemover = new javax.swing.JButton("Remover");
        btnRemover.addActionListener(evt -> removerCurso());

        painel.add(btnAdicionar);
        painel.add(btnEditar);
        painel.add(btnRemover);

        // Tabela para exibir os cursos
        String[] colunas = {"ID", "Nome", "Código", "C. Horária", "Vagas", "Ativo"};
        tabelaModelo = new DefaultTableModel(colunas, 0);
        tabelaCursos = new JTable(tabelaModelo);
        
        // Adicionando os componentes à janela
        getContentPane().add(new JScrollPane(tabelaCursos), java.awt.BorderLayout.CENTER);
        getContentPane().add(painel, java.awt.BorderLayout.SOUTH);
    }

    private void carregarCursosNaTabela() {
        // Limpa a tabela
        tabelaModelo.setRowCount(0);
        
        // Busca os cursos usando o controller
        List<Curso> cursos = this.cursoController.getAllCursos();
        
        // Preenche a tabela
        for (Curso curso : cursos) {
            tabelaModelo.addRow(new Object[]{
                curso.getId(),
                curso.getNome(),
                curso.getCodigo(),
                curso.getCargaHoraria(),
                curso.getVagas(),
                curso.isAtivo()
            });
        }
    }

    // Ações dos botões (simplificadas para demonstração)
    private void adicionarCurso() {
        String nome = JOptionPane.showInputDialog(this, "Nome do Curso:", "Adicionar Curso", JOptionPane.PLAIN_MESSAGE);
        if (nome != null && !nome.trim().isEmpty()) {
            Curso novoCurso = new Curso();
            novoCurso.setNome(nome);
            // Defina os outros atributos aqui (código, vagas, etc.)
            novoCurso.setCodigo("COD-" + (int)(Math.random()*1000));
            novoCurso.setCargaHoraria(200);
            novoCurso.setVagas(40);
            novoCurso.setAtivo(true);
            
            cursoController.saveCurso(novoCurso);
            carregarCursosNaTabela(); // Atualiza a tabela
        }
    }

    private void editarCurso() {
        JOptionPane.showMessageDialog(this, "Funcionalidade de editar a ser implementada.");
    }

    private void removerCurso() {
        JOptionPane.showMessageDialog(this, "Funcionalidade de remover a ser implementada.");
    }
}
