/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.service;

/**
 *
 * @author luis2
 */

import br.com.ifba.curso.dao.CursoIDao;
import br.com.ifba.curso.entity.Curso;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Service: Anotação que marca esta classe como um componente da camada de
 * serviço. O Spring irá criar e gerenciar uma instância (Bean) dela.
 */
@Service
public class CursoService implements CursoIService {

    /**
     * @Autowired: Esta é a mágica da Injeção de Dependência.
     * O Spring irá procurar por um Bean que seja do tipo CursoIDao (que é o
     * nosso CursoDao) e irá injetá-lo automaticamente aqui.
     * * NÃO PRECISAMOS MAIS FAZER: private final CursoIDao cursoDao = new CursoDao();
     */
    @Autowired
    private CursoIDao cursoDao;

    // Métodos que utilizam o DAO injetado
    
    @Override
    public Curso saveCurso(Curso curso) {
        // Futuramente, adicionaremos as validações de negócio aqui
        return cursoDao.save(curso);
    }

    @Override
    public Curso updateCurso(Curso curso) {
        // Futuramente, adicionaremos as validações de negócio aqui
        return cursoDao.update(curso);
    }

    @Override
    public void deleteCurso(Curso curso) {
        cursoDao.delete(curso);
    }

    @Override
    public List<Curso> getAllCursos() {
        return cursoDao.findAll();
    }

    @Override
    public Curso findCursoById(Long id) {
        return cursoDao.findById(id);
    }

    @Override
    public List<Curso> findByName(String nome) {
        return cursoDao.findByName(nome);
    }
}
