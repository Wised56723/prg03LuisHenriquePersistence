/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.main;

/**
 *
 * @author luis2
 */

import br.com.ifba.config.AppConfig;
import br.com.ifba.curso.controller.CursoIController;
import br.com.ifba.curso.view.CursoTela;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    public static void main(String[] args) {
        // 1. Inicializa o contexto do Spring com base na nossa classe de configuração.
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        System.out.println("Spring Context inicializado com Spring Data JPA!");

        // 2. Pede ao Spring para nos fornecer o Bean do Controller.
        CursoIController controller = context.getBean(CursoIController.class);

        // 3. Inicia a interface gráfica (View) na thread correta.
        java.awt.EventQueue.invokeLater(() -> {
            // Cria a tela, passando o controller que o Spring nos deu.
            new CursoTela(controller).setVisible(true);
        });
    }
}