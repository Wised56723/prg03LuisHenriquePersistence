/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.service;

/**
 *
 * @author luis2
 */


import br.com.ifba.curso.entity.Curso;
import br.com.ifba.curso.repository.CursoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CursoService implements CursoIService {

    @Autowired
    private CursoRepository cursoRepository;

    @Override
    public Curso saveCurso(Curso curso) {
        // Aqui você pode adicionar validações antes de salvar
        return cursoRepository.save(curso);
    }

    @Override
    public Curso updateCurso(Curso curso) {
        // O método save() também serve para atualizar se o objeto já tiver um ID
        return cursoRepository.save(curso);
    }

    @Override
    public void deleteCurso(Curso curso) {
        cursoRepository.delete(curso);
    }

    @Override
    public List<Curso> getAllCursos() {
        return cursoRepository.findAll();
    }

    @Override
    public Curso findCursoById(Long id) {
        // O método findById do Spring Data retorna um Optional, para evitar NullPointerException
        return cursoRepository.findById(id).orElse(null);
    }

    @Override
    public List<Curso> findByName(String nome) {
        return cursoRepository.findByNomeContainingIgnoreCase(nome);
    }
}
