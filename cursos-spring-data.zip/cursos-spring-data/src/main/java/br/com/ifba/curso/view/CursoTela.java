/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.curso.view;

/**
 *
 * @author luis2
 */

// Imports necessários para as classes utilizadas
import br.com.ifba.curso.controller.CursoIController;
import br.com.ifba.curso.entity.Curso;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author luis2
 */
public class CursoTela extends javax.swing.JFrame {

    // Variável para guardar a referência do controller gerenciado pelo Spring
    private final CursoIController cursoController;

    // Modelo da tabela para facilitar a manipulação dos dados
    private final DefaultTableModel tabelaModelo;

    /**
     * ESTE É O NOVO CONSTRUTOR.
     * Ele recebe o controller do Spring e inicializa a tela.
     */
    public CursoTela(CursoIController cursoController) {
        this.cursoController = cursoController;
        initComponents(); // Método gerado pelo NetBeans para desenhar os componentes
        this.tabelaModelo = (DefaultTableModel) jTable1.getModel();
        this.carregarCursosNaTabela();
    }

    /**
     * Método para buscar os cursos no banco e exibi-los na JTable.
     */
    private void carregarCursosNaTabela() {
        tabelaModelo.setRowCount(0); // Limpa a tabela

        // Busca todos os cursos através da camada de controle
        List<Curso> cursos = cursoController.getAllCursos();

        // Itera sobre a lista de cursos e adiciona cada um como uma nova linha na tabela
        for (Curso curso : cursos) {
            tabelaModelo.addRow(new Object[]{
                curso.getNome(),
                curso.getId(),
                curso.getCodigo(),
                curso.getCargaHoraria(),
                curso.getVagas()
            });
        }
    }

    // Ação do botão Adicionar
    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {
        String nome = JOptionPane.showInputDialog(this, "Nome do Curso:", "Adicionar Curso", JOptionPane.PLAIN_MESSAGE);
        if (nome != null && !nome.trim().isEmpty()) {
            Curso novoCurso = new Curso();
            novoCurso.setNome(nome);
            novoCurso.setCodigo("COD-" + (System.currentTimeMillis() % 1000));
            novoCurso.setCargaHoraria(200);
            novoCurso.setVagas(40);
            novoCurso.setAtivo(true);
            cursoController.saveCurso(novoCurso);
            carregarCursosNaTabela();
            JOptionPane.showMessageDialog(this, "Curso salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Ação do botão Editar
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {
        int linhaSelecionada = jTable1.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, selecione um curso para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Long idCurso = (Long) jTable1.getValueAt(linhaSelecionada, 1);
        Curso cursoParaEditar = cursoController.findCursoById(idCurso);
        String novoNome = JOptionPane.showInputDialog(this, "Novo nome para o curso:", cursoParaEditar.getNome());
        if (novoNome != null && !novoNome.trim().isEmpty()) {
            cursoParaEditar.setNome(novoNome);
            cursoController.updateCurso(cursoParaEditar);
            carregarCursosNaTabela();
            JOptionPane.showMessageDialog(this, "Curso atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Ação do botão Excluir
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        int linhaSelecionada = jTable1.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, selecione um curso para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Long idCurso = (Long) jTable1.getValueAt(linhaSelecionada, 1);
        int resposta = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir este curso?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            cursoController.deleteCurso(cursoController.findCursoById(idCurso));
            carregarCursosNaTabela();
            JOptionPane.showMessageDialog(this, "Curso excluído com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Ação do botão Pesquisar
    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {
        String nomeBusca = txtPesquisar.getText();
        tabelaModelo.setRowCount(0); // Limpa a tabela
        List<Curso> cursos = cursoController.findByName(nomeBusca);
        for (Curso curso : cursos) {
            tabelaModelo.addRow(new Object[]{
                curso.getNome(),
                curso.getId(),
                curso.getCodigo(),
                curso.getCargaHoraria(),
                curso.getVagas()
            });
        }
    }
    
    // O MÉTODO MAIN ABAIXO É GERADO PELO NETBEANS E NÃO SERÁ MAIS USADO.
    // O ERRO DE COMPILAÇÃO NELE PODE SER IGNORADO.
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            // A linha abaixo causa um erro de compilação porque o construtor padrão foi removido.
            // Isso é esperado e correto. A aplicação deve ser iniciada pela classe br.com.ifba.main.Main.
            // new CursoTela().setVisible(true); 
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnAdicionar = new javax.swing.JButton();
        txtPesquisar = new javax.swing.JTextField();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        javax.swing.JButton btnPesquisarAcao = new javax.swing.JButton(); // Botão de Pesquisa

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"Curso", "ID ", "Código do Curso", "Carga Hóraria", "Vagas"}
        ) {
            boolean[] canEdit = new boolean [] {false, false, false, false, false};
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btnAdicionar.setText("Adicionar");
        btnAdicionar.addActionListener(evt -> btnAdicionarActionPerformed(evt));

        btnEditar.setText("Editar");
        btnEditar.addActionListener(evt -> btnEditarActionPerformed(evt));

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(evt -> btnExcluirActionPerformed(evt));
        
        btnPesquisarAcao.setText("Pesquisar");
        btnPesquisarAcao.addActionListener(evt -> btnPesquisarActionPerformed(evt));

        // Layout (ajustado para incluir o botão de pesquisar)
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 471, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAdicionar, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtPesquisar)
                    .addComponent(btnPesquisarAcao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_size, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPesquisarAcao)
                        .addGap(30, 30, 30)
                        .addComponent(btnAdicionar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>                        

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtPesquisar;
    // End of variables declaration                   
}
